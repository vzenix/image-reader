# Configuration of plugin

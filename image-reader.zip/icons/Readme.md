# Icons of plugins

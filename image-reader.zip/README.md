
# Image Reader

Plugin for Firefox and Chrome for view all images of a loaded page

# Installers

* Install in firefox: https://addons.mozilla.org/es/firefox/addon/image-reader/
* Install in chrome: Add it manually

# How to

Only press the top icon in your browser and the image viewer will be open.

You can control it with the button or can user your keyborard (directional keys)

Press "ESC" to close.
